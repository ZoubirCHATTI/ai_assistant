# -*- coding: utf-8 -*-
"""
Module d'analyse de corrélation météo et retards TER
Intègre des données météo depuis différentes APIs
"""

import streamlit as st
import pandas as pd
import requests
from datetime import datetime, timedelta
import numpy as np
from scipy import stats
import plotly.graph_objects as go
import plotly.express as px


class WeatherAnalyzer:
    """Analyseur de corrélation météo-retards"""
    
    def __init__(self, df_ter: pd.DataFrame):
        self.df_ter = df_ter
        self.df_enriched = None
        
        # Mapping des gares principales avec leurs coordonnées
        self.gare_coordinates = {
            'Paris': {'lat': 48.8566, 'lon': 2.3522},
            'Lyon': {'lat': 45.7640, 'lon': 4.8357},
            'Marseille': {'lat': 43.2965, 'lon': 5.3698},
            'Lille': {'lat': 50.6292, 'lon': 3.0573},
            'Toulouse': {'lat': 43.6047, 'lon': 1.4442},
            'Bordeaux': {'lat': 44.8378, 'lon': -0.5792},
            'Nantes': {'lat': 47.2184, 'lon': -1.5536},
            'Strasbourg': {'lat': 48.5734, 'lon': 7.7521},
            'Rennes': {'lat': 48.1173, 'lon': -1.6778},
            'Grenoble': {'lat': 45.1885, 'lon': 5.7245}
        }
    
    # ═══════════════════════════════════════════════════════════════════
    # RÉCUPÉRATION DES DONNÉES MÉTÉO
    # ═══════════════════════════════════════════════════════════════════
    
    def get_weather_from_open_meteo(self, lat: float, lon: float, date: str) -> dict:
        """
        Récupère les données météo depuis Open-Meteo (API gratuite et complète)
        Alternative à Windguru, plus fiable pour les données historiques
        
        Args:
            lat: Latitude
            lon: Longitude
            date: Date au format 'YYYY-MM-DD'
        
        Returns:
            dict: Données météo
        """
        try:
            # API Open-Meteo (gratuite, pas de clé nécessaire)
            url = "https://archive-api.open-meteo.com/v1/archive"
            
            params = {
                'latitude': lat,
                'longitude': lon,
                'start_date': date,
                'end_date': date,
                'daily': [
                    'temperature_2m_max',
                    'temperature_2m_min',
                    'temperature_2m_mean',
                    'precipitation_sum',
                    'rain_sum',
                    'snowfall_sum',
                    'windspeed_10m_max',
                    'windgusts_10m_max'
                ],
                'timezone': 'Europe/Paris'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'daily' in data:
                daily = data['daily']
                return {
                    'temperature_max': daily.get('temperature_2m_max', [None])[0],
                    'temperature_min': daily.get('temperature_2m_min', [None])[0],
                    'temperature_mean': daily.get('temperature_2m_mean', [None])[0],
                    'precipitation': daily.get('precipitation_sum', [None])[0],
                    'rain': daily.get('rain_sum', [None])[0],
                    'snow': daily.get('snowfall_sum', [None])[0],
                    'wind_speed': daily.get('windspeed_10m_max', [None])[0],
                    'wind_gusts': daily.get('windgusts_10m_max', [None])[0]
                }
            
            return {}
            
        except Exception as e:
            st.warning(f"⚠️ Erreur API météo pour {date}: {e}")
            return {}
    
    def get_weather_from_openweather(self, lat: float, lon: float, date: str, api_key: str) -> dict:
        """
        Récupère les données météo depuis OpenWeatherMap (nécessite clé API)
        
        Args:
            lat: Latitude
            lon: Longitude
            date: Date au format 'YYYY-MM-DD'
            api_key: Clé API OpenWeatherMap
        """
        try:
            # Convertir la date en timestamp
            dt = datetime.strptime(date, '%Y-%m-%d')
            timestamp = int(dt.timestamp())
            
            url = f"https://api.openweathermap.org/data/3.0/onecall/timemachine"
            
            params = {
                'lat': lat,
                'lon': lon,
                'dt': timestamp,
                'appid': api_key,
                'units': 'metric'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'data' in data and len(data['data']) > 0:
                weather = data['data'][0]
                return {
                    'temperature': weather.get('temp'),
                    'feels_like': weather.get('feels_like'),
                    'pressure': weather.get('pressure'),
                    'humidity': weather.get('humidity'),
                    'wind_speed': weather.get('wind_speed'),
                    'rain': weather.get('rain', {}).get('1h', 0),
                    'snow': weather.get('snow', {}).get('1h', 0),
                    'weather_main': weather.get('weather', [{}])[0].get('main'),
                    'weather_description': weather.get('weather', [{}])[0].get('description')
                }
            
            return {}
            
        except Exception as e:
            st.warning(f"⚠️ Erreur OpenWeatherMap pour {date}: {e}")
            return {}
    
    # ═══════════════════════════════════════════════════════════════════
    # ENRICHISSEMENT DU DATASET
    # ═══════════════════════════════════════════════════════════════════
    
    @st.cache_data(ttl=86400, show_spinner="🌦️ Enrichissement avec données météo...")
    def enrich_with_weather(_self, sample_size: int = 1000, use_api_key: str = None):
        """
        Enrichit le dataset TER avec des données météo
        
        Args:
            sample_size: Nombre d'enregistrements à enrichir (pour limiter les appels API)
            use_api_key: Clé API OpenWeatherMap (optionnel)
        """
        df = _self.df_ter.copy()
        
        # Échantillonnage pour limiter les appels API
        if len(df) > sample_size:
            st.info(f"📊 Échantillonnage de {sample_size} enregistrements sur {len(df)}")
            df = df.sample(n=sample_size, random_state=42)
        
        # Vérifier la présence des colonnes nécessaires
        if 'date' not in df.columns:
            st.error("❌ Colonne 'date' nécessaire pour l'enrichissement météo")
            return None
        
        # Initialiser les colonnes météo
        weather_columns = [
            'temperature_max', 'temperature_min', 'temperature_mean',
            'precipitation', 'rain', 'snow', 'wind_speed', 'wind_gusts',
            'weather_severity_score'
        ]
        
        for col in weather_columns:
            df[col] = None
        
        # Déterminer la région/gare pour chaque ligne
        if 'region' in df.columns:
            # Mapper les régions aux grandes villes
            region_to_city = {
                'Île-de-France': 'Paris',
                'Auvergne-Rhône-Alpes': 'Lyon',
                "Provence-Alpes-Côte d'Azur": 'Marseille',
                'Hauts-de-France': 'Lille',
                'Occitanie': 'Toulouse',
                'Nouvelle-Aquitaine': 'Bordeaux',
                'Pays de la Loire': 'Nantes',
                'Grand Est': 'Strasbourg',
                'Bretagne': 'Rennes'
            }
            df['city'] = df['region'].map(region_to_city).fillna('Paris')
        else:
            df['city'] = 'Paris'  # Par défaut
        
        # Boucle d'enrichissement
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        unique_date_city = df[['date', 'city']].drop_duplicates()
        total = len(unique_date_city)
        
        weather_cache = {}  # Cache pour éviter les appels redondants
        
        for idx, (date, city) in enumerate(zip(unique_date_city['date'], unique_date_city['city'])):
            # Mise à jour de la progression
            progress = (idx + 1) / total
            progress_bar.progress(progress)
            status_text.text(f"🌦️ Récupération météo: {idx + 1}/{total} ({city} - {date.strftime('%Y-%m-%d')})")
            
            # Clé de cache
            cache_key = f"{city}_{date.strftime('%Y-%m-%d')}"
            
            if cache_key in weather_cache:
                weather_data = weather_cache[cache_key]
            else:
                # Coordonnées de la ville
                coords = _self.gare_coordinates.get(city, {'lat': 48.8566, 'lon': 2.3522})
                
                # Récupération des données météo
                if use_api_key:
                    weather_data = _self.get_weather_from_openweather(
                        coords['lat'], coords['lon'],
                        date.strftime('%Y-%m-%d'),
                        use_api_key
                    )
                else:
                    weather_data = _self.get_weather_from_open_meteo(
                        coords['lat'], coords['lon'],
                        date.strftime('%Y-%m-%d')
                    )
                
                weather_cache[cache_key] = weather_data
            
            # Mise à jour du DataFrame
            mask = (df['date'] == date) & (df['city'] == city)
            
            for key, value in weather_data.items():
                if key in df.columns:
                    df.loc[mask, key] = value
        
        progress_bar.empty()
        status_text.empty()
        
        # Calcul du score de sévérité météo
        df = _self._calculate_weather_severity(df)
        
        _self.df_enriched = df
        
        st.success(f"✅ Dataset enrichi avec {len(df)} enregistrements météo")
        
        return df
    
    def _calculate_weather_severity(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calcule un score de sévérité météo (0-100)
        Plus le score est élevé, plus les conditions sont difficiles
        """
        score = pd.Series(0, index=df.index)
        
        # Température extrême (< 0°C ou > 35°C)
        if 'temperature_mean' in df.columns:
            score += ((df['temperature_mean'] < 0) | (df['temperature_mean'] > 35)) * 20
        
        # Précipitations importantes (> 10mm)
        if 'precipitation' in df.columns:
            score += (df['precipitation'] > 10) * 15
            score += (df['precipitation'] > 30) * 25  # Pluies très fortes
        
        # Neige
        if 'snow' in df.columns:
            score += (df['snow'] > 0) * 30
            score += (df['snow'] > 5) * 20  # Neige abondante
        
        # Vent fort (> 60 km/h)
        if 'wind_speed' in df.columns:
            score += (df['wind_speed'] > 60) * 25
        
        # Rafales très fortes (> 90 km/h)
        if 'wind_gusts' in df.columns:
            score += (df['wind_gusts'] > 90) * 30
        
        df['weather_severity_score'] = score.clip(0, 100)
        
        return df
    
    # ═══════════════════════════════════════════════════════════════════
    # ANALYSE DE CORRÉLATION
    # ═══════════════════════════════════════════════════════════════════
    
    def analyze_weather_impact(self) -> dict:
        """
        Analyse l'impact de la météo sur les retards/annulations
        
        Returns:
            dict: Résultats de l'analyse
        """
        if self.df_enriched is None:
            return {'error': 'Dataset non enrichi. Lancez enrich_with_weather() d\'abord.'}
        
        df = self.df_enriched
        
        results = {}
        
        # 1. Corrélation avec le taux de régularité
        if 'taux_regularite' in df.columns and 'weather_severity_score' in df.columns:
            # Supprimer les valeurs manquantes
            df_clean = df[['taux_regularite', 'weather_severity_score']].dropna()
            
            if len(df_clean) > 10:
                correlation, p_value = stats.pearsonr(
                    df_clean['taux_regularite'],
                    df_clean['weather_severity_score']
                )
                
                results['correlation_regularite_meteo'] = {
                    'correlation': correlation,
                    'p_value': p_value,
                    'significance': 'Significatif' if p_value < 0.05 else 'Non significatif',
                    'interpretation': self._interpret_correlation(correlation)
                }
        
        # 2. Comparaison retards par conditions météo
        if 'nombre_trains_retard' in df.columns and 'weather_severity_score' in df.columns:
            # Catégoriser la sévérité météo
            df['meteo_category'] = pd.cut(
                df['weather_severity_score'],
                bins=[-1, 20, 40, 60, 100],
                labels=['Bonne', 'Correcte', 'Difficile', 'Extrême']
            )
            
            retards_by_weather = df.groupby('meteo_category')['nombre_trains_retard'].mean()
            results['retards_par_meteo'] = retards_by_weather.to_dict()
        
        # 3. Impact de la neige
        if 'snow' in df.columns and 'taux_regularite' in df.columns:
            df_avec_neige = df[df['snow'] > 0]
            df_sans_neige = df[df['snow'] == 0]
            
            if len(df_avec_neige) > 0 and len(df_sans_neige) > 0:
                regularite_avec_neige = df_avec_neige['taux_regularite'].mean()
                regularite_sans_neige = df_sans_neige['taux_regularite'].mean()
                
                results['impact_neige'] = {
                    'regularite_avec_neige': regularite_avec_neige,
                    'regularite_sans_neige': regularite_sans_neige,
                    'difference': regularite_sans_neige - regularite_avec_neige
                }
        
        # 4. Impact du vent fort
        if 'wind_gusts' in df.columns and 'taux_regularite' in df.columns:
            df_vent_fort = df[df['wind_gusts'] > 90]
            df_vent_normal = df[df['wind_gusts'] <= 90]
            
            if len(df_vent_fort) > 0 and len(df_vent_normal) > 0:
                results['impact_vent'] = {
                    'regularite_vent_fort': df_vent_fort['taux_regularite'].mean(),
                    'regularite_vent_normal': df_vent_normal['taux_regularite'].mean(),
                    'difference': df_vent_normal['taux_regularite'].mean() - df_vent_fort['taux_regularite'].mean()
                }
        
        # 5. Impact de la pluie
        if 'rain' in df.columns and 'taux_regularite' in df.columns:
            df_pluie_forte = df[df['rain'] > 10]
            df_pluie_faible = df[df['rain'] <= 10]
            
            if len(df_pluie_forte) > 0 and len(df_pluie_faible) > 0:
                results['impact_pluie'] = {
                    'regularite_pluie_forte': df_pluie_forte['taux_regularite'].mean(),
                    'regularite_pluie_faible': df_pluie_faible['taux_regularite'].mean(),
                    'difference': df_pluie_faible['taux_regularite'].mean() - df_pluie_forte['taux_regularite'].mean()
                }
        
        return results
    
    def _interpret_correlation(self, r: float) -> str:
        """Interprète le coefficient de corrélation"""
        abs_r = abs(r)
        direction = "négative" if r < 0 else "positive"
        
        if abs_r < 0.2:
            strength = "très faible"
        elif abs_r < 0.4:
            strength = "faible"
        elif abs_r < 0.6:
            strength = "modérée"
        elif abs_r < 0.8:
            strength = "forte"
        else:
            strength = "très forte"
        
        return f"Corrélation {direction} {strength}"
    
    # ═══════════════════════════════════════════════════════════════════
    # VISUALISATIONS
    # ═══════════════════════════════════════════════════════════════════
    
    def plot_weather_impact(self):
        """Crée des visualisations de l'impact météo"""
        
        if self.df_enriched is None:
            st.warning("⚠️ Aucune donnée météo disponible")
            return
        
        df = self.df_enriched
        
        st.subheader("🌦️ Impact des Conditions Météorologiques sur la Ponctualité")
        
        # Graphique 1 : Corrélation sévérité météo vs régularité
        if 'weather_severity_score' in df.columns and 'taux_regularite' in df.columns:
            fig1 = px.scatter(
                df,
                x='weather_severity_score',
                y='taux_regularite',
                color='city' if 'city' in df.columns else None,
                title="Corrélation entre Sévérité Météo et Régularité",
                labels={
                    'weather_severity_score': 'Score de Sévérité Météo (0-100)',
                    'taux_regularite': 'Taux de Régularité (%)'
                },
                trendline="ols"
            )
            st.plotly_chart(fig1, use_container_width=True)
        
        # Graphique 2 : Régularité par catégorie météo
        if 'meteo_category' in df.columns and 'taux_regularite' in df.columns:
            df_grouped = df.groupby('meteo_category')['taux_regularite'].agg(['mean', 'count']).reset_index()
            
            fig2 = go.Figure()
            fig2.add_trace(go.Bar(
                x=df_grouped['meteo_category'],
                y=df_grouped['mean'],
                text=df_grouped['mean'].round(2),
                textposition='auto',
                marker_color=['green', 'yellow', 'orange', 'red']
            ))
            
            fig2.update_layout(
                title="Régularité Moyenne par Condition Météo",
                xaxis_title="Condition Météo",
                yaxis_title="Taux de Régularité Moyen (%)",
                showlegend=False
            )
            
            st.plotly_chart(fig2, use_container_width=True)
        
        # Graphique 3 : Impact de la neige
        if 'snow' in df.columns and 'taux_regularite' in df.columns:
            df['avec_neige'] = df['snow'] > 0
            
            fig3 = px.box(
                df,
                x='avec_neige',
                y='taux_regularite',
                title="Impact de la Neige sur la Régularité",
                labels={
                    'avec_neige': 'Présence de Neige',
                    'taux_regularite': 'Taux de Régularité (%)'
                },
                color='avec_neige',
                color_discrete_map={True: 'lightblue', False: 'lightgreen'}
            )
            
            st.plotly_chart(fig3, use_container_width=True)
